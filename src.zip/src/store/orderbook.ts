import { create } from 'zustand';
export type Level = { price: number; quantity: number }
export type Side = 'bid' | 'ask'

interface OBState {
  bids: Level[]
  asks: Level[]
  venues: string[]
  activeVenues: Set<string>
  setData: (venue: string, side: Side, levels: Level[]) => void
  toggleVenue: (venue: string) => void
}

export const useOrderbookStore = create<OBState>(set => ({
  bids: [],
  asks: [],
  venues: [], 
  activeVenues: new Set(),
  setData: (venue, side, levels) =>
    set(state => {
      const next = { ...state }
      if (!next.venues.includes(venue)) next.venues.push(venue)
      if (!next.activeVenues.has(venue)) next.activeVenues.add(venue)
      next[side === 'bid' ? 'bids' : 'asks'] = levels
      return next
    }),
  toggleVenue: venue =>
    set(state => {
      const next = new Set(state.activeVenues)
      next.has(venue) ? next.delete(venue) : next.add(venue)
      return { activeVenues: next }
    }),
}))
