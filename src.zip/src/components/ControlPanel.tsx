'use client'

import { useOrderbookStore } from '@/store/orderbook'

interface ControlPanelProps {
  autoRotate: boolean
  setAutoRotate: React.Dispatch<React.SetStateAction<boolean>>
  rotationSpeed: number
  setRotationSpeed: React.Dispatch<React.SetStateAction<number>>
}

export default function ControlPanel({
  autoRotate,
  setAutoRotate,
  rotationSpeed,
  setRotationSpeed,
}: ControlPanelProps) {
  const { venues, activeVenues, toggleVenue } = useOrderbookStore()

  return (
    <div className="absolute top-4 left-4 p-4 bg-white bg-opacity-90 dark:bg-gray-800 rounded-lg shadow-lg w-72 space-y-4">
      <h2 className="text-lg font-semibold text-gray-800 dark:text-gray-100">Controls</h2>

      {/* Auto-Rotate Toggle */}
      <div className="space-y-1">
        <label className="flex items-center space-x-2">
          <input
            type="checkbox"
            checked={autoRotate}
            onChange={e => setAutoRotate(e.target.checked)}
            className="form-checkbox h-4 w-4 text-blue-600"
          />
          <span className="text-sm text-gray-700 dark:text-gray-200">Auto-Rotate</span>
        </label>
      </div>

      {/* Rotation Speed Slider */}
      <div className="space-y-1">
        <label htmlFor="speed" className="block text-sm text-gray-700 dark:text-gray-200">
          Speed: {rotationSpeed.toFixed(2)} rad/s
        </label>
        <input
          id="speed"
          type="range"
          min={0}
          max={2}
          step={0.01}
          value={rotationSpeed}
          onChange={e => setRotationSpeed(+e.target.value)}
          className="w-full"
        />
      </div>

      <hr className="border-gray-300 dark:border-gray-600" />

      {/* Venue Filter */}
      <div className="space-y-1">
        <h3 className="text-sm font-medium text-gray-800 dark:text-gray-100">Venues</h3>
        <div className="grid grid-cols-2 gap-1 max-h-32 overflow-auto">
          {venues.map(v => (
            <label key={v} className="flex items-center space-x-1 text-sm text-gray-700 dark:text-gray-200">
              <input
                type="checkbox"
                checked={activeVenues.has(v)}
                onChange={() => toggleVenue(v)}
                className="form-checkbox h-4 w-4 text-green-600"
              />
              <span>{v}</span>
            </label>
          ))}
        </div>
      </div>
    </div>
  )
}
