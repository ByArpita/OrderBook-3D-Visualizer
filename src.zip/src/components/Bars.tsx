'use client'

import { useRef } from 'react'
import { useEffect } from 'react'
import * as THREE from 'three'
import { useOrderbookStore } from '@/store/orderbook'
import { Text } from '@react-three/drei'

const BAR_WIDTH = 3
const BAR_DEPTH = 3
const HEIGHT_SCALE = 2  // Smaller = taller bars

interface BarsProps {
  side: 'bids' | 'asks'
}

export default function Bars({ side }: BarsProps) {
  const meshRef = useRef<THREE.InstancedMesh>(null)
  const levels = useOrderbookStore(state => state[side])

  const prices = levels.map(l => l.price)
  const quantities = levels.map(l => l.quantity)

  const minPrice = Math.min(...prices)
  const maxPrice = Math.max(...prices)
  const midPrice = (minPrice + maxPrice) / 2
  const spread = maxPrice - minPrice || 1
  const PRICE_SCALE = 200 / spread  // Increased for better X spacing

  const maxQty = Math.max(...quantities) || 1

  
  const prevQuantitiesRef = useRef<number[]>([])
  
  useEffect(() => {
    if (!meshRef.current) return
    const inst = meshRef.current

    for (let i = 0; i < levels.length; i++) {
      const level = levels[i]
      const matrix = new THREE.Matrix4()

      const x = (level.price - midPrice) * PRICE_SCALE

      //const y = (level.quantity / maxQty) * 100
      const prevY = prevQuantitiesRef.current[i] || 0
      const targetY = (level.quantity / maxQty) * 100
      const y = THREE.MathUtils.lerp(prevY, targetY, 0.2)
      prevQuantitiesRef.current[i] = y

      const z = side === 'bids' ? -20 : 20

      matrix.makeTranslation(x, y / 2, z)
      matrix.scale(new THREE.Vector3(BAR_WIDTH, y, BAR_DEPTH))
      inst.setMatrixAt(i, matrix)
    }

    inst.count = levels.length
    inst.instanceMatrix.needsUpdate = true
  }, [levels, midPrice, maxQty, PRICE_SCALE, side])


  const PriceLabels = () => {
    const ticks = 5
    const priceInterval = spread / (ticks - 1)

    return (
      <>
        {Array.from({ length: ticks }, (_, i) => {
          const price = minPrice + i * priceInterval
          const x = (price - midPrice) * PRICE_SCALE

          return (
            <Text
              key={i}
              position={[x, 0, side === 'asks' ? 60 : -60]} // offset Z to avoid bar overlap
              fontSize={2}
              color="white"
              anchorX="center"
              anchorY="top"
            >
              {price.toFixed(0)}
            </Text>
          )
        })}
      </>
    )
  }

  const QuantityLabels = () => {
    const ticks = 5
    return (
      <>
        {Array.from({ length: ticks }, (_, i) => {
          const y = (i / (ticks - 1)) * 100
          return (
            <Text
              key={i}
              position={[0, y, side === 'asks' ? 60 : -60]} // aligned with Z axis
              fontSize={2}
              color="white"
              anchorX="right"
              anchorY="middle"
            >
              {(maxQty * i / (ticks - 1)).toFixed(0)}
            </Text>
          )
        })}
      </>
    )
  }

  return (
    <>
      <instancedMesh
        ref={meshRef}
        args={[undefined, undefined, levels.length || 1]}
      >
        <boxGeometry />
        <meshStandardMaterial color={side === 'bids' ? 'green' : 'red'} />
      </instancedMesh>

      {/* Render axes once (on asks side only) */}
      {side === 'asks' && (
        <>
          <PriceLabels />
          <QuantityLabels />
        </>
      )}
    </>
  )
}
