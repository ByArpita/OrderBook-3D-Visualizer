'use client'

import { Canvas, useFrame } from '@react-three/fiber'
import { OrbitControls } from '@react-three/drei'
import { useRef } from 'react'
import { useBinanceDepth } from '@/hooks/useBinanceDepth'
import Bars from './Bars'
import * as THREE from 'three'

interface OrderbookSceneProps {
  autoRotate: boolean
  rotationSpeed: number
}

function RotatingGroup({ autoRotate, rotationSpeed }: OrderbookSceneProps) {
  const groupRef = useRef<THREE.Group>(null)

  useFrame((_, delta) => {
    if (autoRotate && groupRef.current) {
      groupRef.current.rotation.y += rotationSpeed * delta
    }
  })

  return (
    <group ref={groupRef}>
      <Bars side="bids" />
      <Bars side="asks" />
    </group>
  )
}

export default function OrderbookScene({ autoRotate, rotationSpeed }: OrderbookSceneProps) {
  useBinanceDepth('btcusdt', 100)

  return (
    <Canvas camera={{ position: [0, 30, 200], fov: 60 }}>
      <ambientLight intensity={0.5} />
      <directionalLight position={[10, 20, 10]} />
      
      {/* Controlled group rotation */}
      <RotatingGroup autoRotate={autoRotate} rotationSpeed={rotationSpeed} />

      {/* Manual controls always active */}
      <OrbitControls
        enablePan
        enableZoom
        enableRotate
        autoRotate={autoRotate}
        autoRotateSpeed={rotationSpeed}
        target={[0, 50, 0]}
      />
    </Canvas>
  )
}
